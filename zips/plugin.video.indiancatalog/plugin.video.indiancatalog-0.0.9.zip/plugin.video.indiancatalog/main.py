import os
import sys
import json
import datetime
import urllib.request
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

HANDLE = int(sys.argv[1])
BASE = sys.argv[0]
ADDON = xbmcaddon.Addon()
IMG = "https://image.tmdb.org/t/p/w500"
BACK = "https://image.tmdb.org/t/p/w1280"
SUB_SOURCES = ["https://opensubtitles-v3.strem.io"]

LANGS = [
    ("Tamil", "ta"), ("Telugu", "te"), ("Malayalam", "ml"),
    ("Kannada", "kn"), ("Hindi", "hi"), ("Bengali", "bn"),
    ("Marathi", "mr"), ("Punjabi", "pa"),
]

LANG_CODES = {
    "English": ("en", "eng", "english"),
    "Tamil": ("ta", "tam", "tamil"),
    "Telugu": ("te", "tel", "telugu"),
    "Malayalam": ("ml", "mal", "malayalam"),
    "Kannada": ("kn", "kan", "kannada"),
    "Hindi": ("hi", "hin", "hindi"),
    "Bengali": ("bn", "ben", "bengali"),
    "Marathi": ("mr", "mar", "marathi"),
    "Punjabi": ("pa", "pan", "punjabi"),
}

PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
STATE_FILE = os.path.join(PROFILE, "state.json")


def url(**kw):
    return BASE + "?" + urllib.parse.urlencode(kw)


def clean(text):
    return " ".join((text or "").split())


def tmdb(path, **params):
    key = ADDON.getSetting("tmdb_key").strip()
    if not key:
        xbmcgui.Dialog().ok("Indian Cinema Catalog", "Open the addon settings and enter your TMDB API key first.")
        return None
    params["api_key"] = key
    u = "https://api.themoviedb.org/3" + path + "?" + urllib.parse.urlencode(params)
    last = ""
    for attempt in range(3):
        try:
            req = urllib.request.Request(u, headers={"User-Agent": "Kodi"})
            with urllib.request.urlopen(req, timeout=15) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception as e:
            last = str(e)
            xbmc.sleep(1000)
    xbmcgui.Dialog().notification("TMDB error", last, xbmcgui.NOTIFICATION_ERROR)
    return None


def add_folder(label, link):
    xbmcplugin.addDirectoryItem(HANDLE, link, xbmcgui.ListItem(label=label), True)


def load_state():
    try:
        with open(STATE_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(st):
    try:
        os.makedirs(PROFILE, exist_ok=True)
        with open(STATE_FILE, "w") as f:
            json.dump(st, f)
    except Exception:
        pass


def mark_state(tag, key):
    v = load_state().get(key)
    if not v:
        return
    if v.get("watched"):
        tag.setPlaycount(1)
    elif v.get("pos") and v.get("total"):
        try:
            tag.setResumePoint(float(v["pos"]), float(v["total"]))
        except Exception:
            pass


def fmt(sec):
    sec = int(sec)
    h, r = divmod(sec, 3600)
    m, s = divmod(r, 60)
    if h:
        return "%d:%02d:%02d" % (h, m, s)
    return "%d:%02d" % (m, s)


def main_menu():
    add_folder("Search Movies", url(action="search", kind="movie"))
    add_folder("Search Series", url(action="search", kind="tv"))
    for name, code in LANGS:
        add_folder(name, url(action="lang", lang=code))
    xbmcplugin.endOfDirectory(HANDLE)


def lang_menu(lang):
    add_folder("Movies", url(action="cat", kind="movie", lang=lang))
    add_folder("Series", url(action="cat", kind="tv", lang=lang))
    xbmcplugin.endOfDirectory(HANDLE)


def cat_menu(kind, lang):
    add_folder("New Releases", url(action="list", kind=kind, lang=lang, sort="new", page=1))
    add_folder("Popular", url(action="list", kind=kind, lang=lang, sort="popular", page=1))
    add_folder("Top Rated", url(action="list", kind=kind, lang=lang, sort="top", page=1))
    xbmcplugin.endOfDirectory(HANDLE)


def art_for(m):
    art = {}
    if m.get("poster_path"):
        art["poster"] = IMG + m["poster_path"]
        art["thumb"] = IMG + m["poster_path"]
    if m.get("backdrop_path"):
        art["fanart"] = BACK + m["backdrop_path"]
    return art


def movie_item(m):
    title = m.get("title") or "Unknown"
    rd = m.get("release_date") or ""
    li = xbmcgui.ListItem(label=title)
    tag = li.getVideoInfoTag()
    tag.setTitle(title)
    tag.setPlot(m.get("overview") or "")
    tag.setMediaType("movie")
    mark_state(tag, "m:%s" % m["id"])
    if len(rd) >= 4 and rd[:4].isdigit():
        tag.setYear(int(rd[:4]))
    if m.get("vote_average"):
        tag.setRating(float(m["vote_average"]))
    li.setArt(art_for(m))
    li.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(HANDLE, url(action="play", tmdb_id=m["id"], title=title), li, False)


def series_item(m):
    title = m.get("name") or "Unknown"
    fd = m.get("first_air_date") or ""
    li = xbmcgui.ListItem(label=title)
    tag = li.getVideoInfoTag()
    tag.setTitle(title)
    tag.setPlot(m.get("overview") or "")
    tag.setMediaType("tvshow")
    if len(fd) >= 4 and fd[:4].isdigit():
        tag.setYear(int(fd[:4]))
    if m.get("vote_average"):
        tag.setRating(float(m["vote_average"]))
    li.setArt(art_for(m))
    xbmcplugin.addDirectoryItem(HANDLE, url(action="seasons", tmdb_id=m["id"], title=title), li, True)


def show_results(kind, data, next_params, page):
    if data:
        for m in data.get("results", []):
            if kind == "movie":
                movie_item(m)
            else:
                series_item(m)
        if page < data.get("total_pages", 1):
            nxt = dict(next_params)
            nxt["page"] = page + 1
            add_folder("Next page >>", url(**nxt))
    xbmcplugin.setContent(HANDLE, "movies" if kind == "movie" else "tvshows")
    xbmcplugin.endOfDirectory(HANDLE)


def list_titles(kind, lang, sort, page):
    p = {"with_original_language": lang, "page": page, "include_adult": "false"}
    dk = "primary_release_date" if kind == "movie" else "first_air_date"
    if sort == "new":
        p["sort_by"] = dk + ".desc"
        p[dk + ".lte"] = datetime.date.today().isoformat()
    elif sort == "top":
        p["sort_by"] = "vote_average.desc"
        p["vote_count.gte"] = 100 if kind == "movie" else 50
    else:
        p["sort_by"] = "popularity.desc"
    data = tmdb("/discover/" + kind, **p)
    show_results(kind, data, {"action": "list", "kind": kind, "lang": lang, "sort": sort}, page)


def search(kind, q, page):
    if not q:
        label = "Search movies" if kind == "movie" else "Search series"
        q = xbmcgui.Dialog().input(label, type=xbmcgui.INPUT_ALPHANUM)
        if not q:
            xbmcplugin.endOfDirectory(HANDLE)
            return
    data = tmdb("/search/" + kind, query=q, page=page, include_adult="false")
    show_results(kind, data, {"action": "search", "kind": kind, "q": q}, page)


def list_seasons(tmdb_id, title):
    d = tmdb("/tv/%s" % tmdb_id)
    if d:
        for s in d.get("seasons", []):
            n = s.get("season_number", 0)
            if n == 0:
                continue
            label = s.get("name") or ("Season %s" % n)
            li = xbmcgui.ListItem(label=label)
            tag = li.getVideoInfoTag()
            tag.setTitle(label)
            tag.setPlot(s.get("overview") or "")
            tag.setMediaType("season")
            pp = s.get("poster_path") or d.get("poster_path")
            if pp:
                li.setArt({"poster": IMG + pp, "thumb": IMG + pp})
            xbmcplugin.addDirectoryItem(HANDLE, url(action="episodes", tmdb_id=tmdb_id, season=n, title=title), li, True)
    xbmcplugin.setContent(HANDLE, "seasons")
    xbmcplugin.endOfDirectory(HANDLE)


def list_episodes(tmdb_id, season, title):
    d = tmdb("/tv/%s/season/%s" % (tmdb_id, season))
    if d:
        for e in d.get("episodes", []):
            num = e.get("episode_number")
            name = e.get("name") or ("Episode %s" % num)
            li = xbmcgui.ListItem(label="%s. %s" % (num, name))
            tag = li.getVideoInfoTag()
            tag.setTitle(name)
            tag.setPlot(e.get("overview") or "")
            tag.setMediaType("episode")
            tag.setSeason(int(season))
            tag.setEpisode(int(num))
            mark_state(tag, "e:%s:%s:%s" % (tmdb_id, season, num))
            if e.get("still_path"):
                li.setArt({"thumb": IMG + e["still_path"]})
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(HANDLE, url(action="playep", tmdb_id=tmdb_id, season=season, episode=num, title=title), li, False)
    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE)


def cinemeta_lookup(kind, name, year, tmdb_id):
    try:
        u = "https://v3-cinemeta.strem.io/catalog/" + kind + "/top/search=" + urllib.parse.quote(name) + ".json"
        with urllib.request.urlopen(u, timeout=15) as r:
            metas = json.loads(r.read().decode("utf-8")).get("metas", [])
        for m in metas:
            same_year = year and str(m.get("year", "")).startswith(year)
            if same_year and m.get("name", "").lower() == name.lower() and m.get("imdb_id"):
                return m["imdb_id"]
        for m in metas:
            if year and str(m.get("year", "")).startswith(year) and m.get("imdb_id"):
                return m["imdb_id"]
    except Exception:
        pass
    return "tmdb:%s" % tmdb_id


def find_imdb(tmdb_id, title):
    d = tmdb("/movie/%s" % tmdb_id, append_to_response="external_ids") or {}
    imdb = d.get("imdb_id") or (d.get("external_ids") or {}).get("imdb_id")
    if imdb:
        return imdb
    return cinemeta_lookup("movie", d.get("title") or title, (d.get("release_date") or "")[:4], tmdb_id)


def find_series_imdb(tmdb_id, title):
    d = tmdb("/tv/%s" % tmdb_id, append_to_response="external_ids") or {}
    imdb = (d.get("external_ids") or {}).get("imdb_id")
    if imdb:
        return imdb
    return cinemeta_lookup("series", d.get("name") or title, (d.get("first_air_date") or "")[:4], tmdb_id)


def get_base():
    base = ADDON.getSetting("aiostreams_url").strip()
    if not base:
        xbmcgui.Dialog().ok("Indian Cinema Catalog", "Open the addon settings and enter your AIOStreams URL first.")
        return None
    base = base.replace("stremio://", "https://")
    if base.endswith("/manifest.json"):
        base = base[:-len("/manifest.json")]
    return base


def quality_match(label, pref):
    t = label.lower()
    if pref == "2160p":
        return "2160p" in t or "4k" in t
    return pref.lower() in t


def fetch_subs(base, kind, sid, stream):
    found = []
    for sub in (stream.get("subtitles") or []):
        if isinstance(sub, dict) and sub.get("url"):
            found.append((sub.get("lang") or "", sub["url"]))
    for sb in [base] + SUB_SOURCES:
        if sb != base and sid.startswith("tmdb:"):
            continue
        try:
            req = urllib.request.Request(sb + "/subtitles/" + kind + "/" + sid + ".json", headers={"User-Agent": "Kodi"})
            with urllib.request.urlopen(req, timeout=15) as r:
                data = json.loads(r.read().decode("utf-8"))
            for sub in data.get("subtitles", []):
                if sub.get("url"):
                    found.append((sub.get("lang") or "", sub["url"]))
        except Exception:
            pass
    eng = LANG_CODES["English"]
    pref = LANG_CODES.get(ADDON.getSetting("sub_lang") or "English", eng)

    def rank(x):
        l = x[0].lower()
        if l in pref:
            return 0
        if l in eng:
            return 1
        return 2

    seen = set()
    out = []
    for lang, u in sorted(found, key=rank):
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out[:30]


def track(key, resume):
    player = xbmc.Player()
    monitor = xbmc.Monitor()
    waited = 0
    while not player.isPlayingVideo() and waited < 90:
        if monitor.waitForAbort(1):
            return
        waited += 1
    if not player.isPlayingVideo():
        return
    if resume:
        monitor.waitForAbort(3)
        try:
            if player.getTime() < resume - 10:
                player.seekTime(resume)
        except Exception:
            pass
    pos = 0
    total = 0
    while player.isPlayingVideo() and not monitor.abortRequested():
        try:
            pos = player.getTime()
            total = player.getTotalTime()
        except Exception:
            pass
        monitor.waitForAbort(3)
    if total > 0:
        st = load_state()
        if pos / total >= 0.9:
            st[key] = {"watched": True}
        elif pos > 60:
            st[key] = {"pos": int(pos), "total": int(total)}
        save_state(st)


def pick_and_play(kind, sid, title, key):
    fail = xbmcgui.ListItem()
    base = get_base()
    if not base:
        xbmcplugin.setResolvedUrl(HANDLE, False, fail)
        return
    streams = []
    err = ""
    for attempt in range(3):
        try:
            req = urllib.request.Request(base + "/stream/" + kind + "/" + sid + ".json", headers={"User-Agent": "Kodi"})
            with urllib.request.urlopen(req, timeout=45) as r:
                data = json.loads(r.read().decode("utf-8"))
            streams = [s for s in data.get("streams", []) if s.get("url")]
            err = ""
        except Exception as e:
            err = str(e)
            streams = []
        if streams:
            break
        if attempt < 2:
            xbmcgui.Dialog().notification("Indian Cinema Catalog", "Looking for streams, try %d of 3" % (attempt + 2), xbmcgui.NOTIFICATION_INFO, 2000)
            xbmc.sleep(3000)
    if err and not streams:
        xbmcgui.Dialog().notification("AIOStreams error", err, xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, fail)
        return
    if not streams:
        xbmcgui.Dialog().ok("Indian Cinema Catalog", "No streams found for " + title)
        xbmcplugin.setResolvedUrl(HANDLE, False, fail)
        return
    labels = []
    for s in streams:
        name = clean(s.get("name"))
        raw = s.get("title") or s.get("description") or ""
        desc = " | ".join(p.strip() for p in raw.splitlines() if p.strip())
        labels.append((name + " - " + desc).strip(" -"))
    pref = ADDON.getSetting("quality") or "Ask every time"
    i = -1
    if pref != "Ask every time":
        for n, lab in enumerate(labels):
            if quality_match(lab, pref):
                i = n
                break
        if i >= 0:
            xbmcgui.Dialog().notification("Auto-picked " + pref, labels[i][:60], xbmcgui.NOTIFICATION_INFO, 2500)
    if i < 0:
        i = xbmcgui.Dialog().select(title, labels)
    if i < 0:
        xbmcplugin.setResolvedUrl(HANDLE, False, fail)
        return
    li = xbmcgui.ListItem(path=streams[i]["url"])
    subs = fetch_subs(base, kind, sid, streams[i])
    if subs:
        li.setSubtitles(subs)
        xbmcgui.Dialog().notification("Indian Cinema Catalog", "%d subtitles loaded" % len(subs), xbmcgui.NOTIFICATION_INFO, 2000)
    resume = 0
    v = load_state().get(key) or {}
    if v.get("pos") and not v.get("watched"):
        if xbmcgui.Dialog().yesno(title, "Resume from " + fmt(v["pos"]) + "?", nolabel="Start over", yeslabel="Resume"):
            resume = int(v["pos"])
            li.setProperty("StartOffset", str(resume))
    xbmcplugin.setResolvedUrl(HANDLE, True, li)
    track(key, resume)


def play(tmdb_id, title):
    pick_and_play("movie", find_imdb(tmdb_id, title), title, "m:%s" % tmdb_id)


def play_episode(tmdb_id, season, episode, title):
    sid = find_series_imdb(tmdb_id, title)
    pick_and_play("series", "%s:%s:%s" % (sid, season, episode), "%s S%sE%s" % (title, season, episode), "e:%s:%s:%s" % (tmdb_id, season, episode))


params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params.get("action")

if action == "lang":
    lang_menu(params["lang"])
elif action == "cat":
    cat_menu(params["kind"], params["lang"])
elif action == "list":
    list_titles(params["kind"], params["lang"], params["sort"], int(params.get("page", 1)))
elif action == "search":
    search(params["kind"], params.get("q", ""), int(params.get("page", 1)))
elif action == "seasons":
    list_seasons(params["tmdb_id"], params.get("title", ""))
elif action == "episodes":
    list_episodes(params["tmdb_id"], params["season"], params.get("title", ""))
elif action == "play":
    play(params["tmdb_id"], params.get("title", ""))
elif action == "playep":
    play_episode(params["tmdb_id"], params["season"], params["episode"], params.get("title", ""))
else:
    main_menu()
